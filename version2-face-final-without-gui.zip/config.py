from pymongo import MongoClient

# Update if using MongoDB Atlas or remote DB
MONGO_URI = "mongodb://localhost:27017"

client = MongoClient(MONGO_URI)
db = client["face_attendance"]
face_collection = db["face_db"]
attendance_collection = db["attendance_log"]
