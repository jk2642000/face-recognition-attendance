# Face Recognition Attendance System

A robust face recognition system for registering users and marking attendance automatically using MTCNN face detection and FaceNet embeddings.

## Features

### Registration System
- Face-based user registration with duplicate detection
- Multiple face samples per person for improved accuracy
- Stores name, phone, address, gender, and birth date
- Automatic unique employee ID generation
- Prevents duplicate registrations with face similarity check

### Recognition System
- Real-time face detection and recognition
- Dynamic age calculation based on birth date
- Gender display (Female/Male/Other)
- Automatic attendance marking
- Visual feedback with color-coded labels
- Debug mode with similarity scores

### Technical Features
- GPU acceleration with CPU fallback
- MongoDB database integration
- Comprehensive error handling
- Tunable recognition parameters
- Multi-camera support

## Requirements

- Python 3.8+
- TensorFlow 2.10+
- OpenCV
- MongoDB
- MTCNN
- Keras-FaceNet

## Installation

1. Clone the repository:
```bash
git clone https://github.com/yourusername/face-recognition-attendance.git
cd face-recognition-attendance
```

2. Install dependencies:
```bash
pip install -r requirements.txt
```

3. Configure MongoDB:
   - Create a file named `config.py` with your MongoDB connection:
   ```python
   from pymongo import MongoClient

   client = MongoClient('mongodb://localhost:27017/')
   db = client['face_recognition']
   face_collection = db['faces']
   attendance_collection = db['attendance']
   ```

## Usage

### Register a New Person
```bash
python register_face.py
```
- Enter personal details when prompted
- Look at the camera for duplicate check
- System will capture 10 face samples

### Recognize Faces and Mark Attendance
```bash
python recognize_face.py
```
- System will detect faces in real-time
- Recognized faces will be marked for attendance
- Press ESC to exit

## Configuration

You can adjust these parameters in the code:

- `THRESHOLD`: Face similarity threshold (0.6 recommended)
- `MATCH_REQUIRED`: Consecutive matches needed (5 recommended)
- `SAVE_COUNT`: Number of face samples to capture (10 default)
- `DEBUG_MODE`: Set to True to see similarity scores

## GPU Support

The system automatically detects and uses GPU if available. For GPU acceleration:
1. Install CUDA Toolkit 11.2+
2. Install cuDNN
3. Install TensorFlow with GPU support

## License

MIT License